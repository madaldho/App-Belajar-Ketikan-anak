=============================================================== 
   YUKMENGENTIK - GAME NGETIK CEPAT 
=============================================================== 
 
CARA INSTALL: 
1. Double-click YukMengetik.exe 
2. Tunggu aplikasi terbuka 
3. Selesai! 
 
PIN ADMIN: 098123 
 
FITUR: 
- Tes mengetik dengan feedback real-time 
- Leaderboard otomatis 
- Admin panel lengkap 
- Import siswa dari Excel 
- Offline, tidak perlu internet 
 
Untuk dokumentasi lengkap, baca CARA_INSTALL.txt 
